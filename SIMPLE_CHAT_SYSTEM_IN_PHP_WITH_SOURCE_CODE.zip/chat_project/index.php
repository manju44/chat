<?php include "layouts/header.php"; ?>
<div class="container">

<center><h2 style="color:white; margin-top:20%">Welcome to simple chat system.</h2></center>
</div>

</body>
</html>
